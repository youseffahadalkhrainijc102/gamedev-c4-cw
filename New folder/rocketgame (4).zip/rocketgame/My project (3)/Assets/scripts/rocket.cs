using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rocket : MonoBehaviour {


    Rigidbody rocketRB;
    AudioSource rocketAudioSource;

    [SerializeField] AudioClip mainEngine;
    [SerializeField] float thrustSpeed = 5.0f;
    [SerializeField] float rotationSpeed = 2.5f;

    // Start is called before the first frame update
    void Start()
    {
        rocketRB = GetComponent<Rigidbody>();
        rocketAudioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

        Rotate();
        thurst();
    }


        void Rotate()
        {
            if (Input.GetKey(KeyCode.A))
            {
                print("Rotate right");
            transform.Rotate(Vector3.forward);
            }
            else if (Input.GetKey(KeyCode.D))
            {
            print("Rotate left");
             transform.Rotate(-Vector3.forward * rotationSpeed);
        }
        }

    void OnCollisionEnter(Collision collision)
    {
        print(collision.gameObject.tag);
        switch (collision.gameObject.tag) {

            case "Freindly":
                print("no proplem");
                    break;

            case "Finish":
                print("you win!!!");
                    break;

                default:
                print("you lose ");
                    break;
                }

    }


    void thurst()
    {

        if (Input.GetKey(KeyCode.Space))
        {
            print("Thursting");
            rocketRB.AddRelativeForce(Vector3.up * thrustSpeed);
            rocketAudioSource.PlayOneShot(mainEngine);
        }
    }

}